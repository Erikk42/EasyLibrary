package Principal;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class Conexao {
 String serverName = "127.0.0.1"; //Endereço do servidor
 String myDataBase = "Biblioteca";//Nome do banco
 String url = "jdbc:mysql://" + serverName + "/" + myDataBase;
 String username = "root";//Usuário do banco de dados
 String password = "";//senha do banco de dados
 Connection Conexao;
 Conexao() throws SQLException {
 Conexao = DriverManager.getConnection(url, username, password);
 }
}